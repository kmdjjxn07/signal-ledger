# 서버 없이 무료로 운영하기 (GitHub Actions + 공개 저장소)

내 컴퓨터를 계속 켜 두지 않아도, GitHub가 정해진 시각마다 시그널 원장을 대신 실행하고
결과를 **공개 웹사이트(GitHub Pages)** 로 보여 주는 방식입니다. 비용은 0원입니다(공개 저장소 기준).

```
[내 컴퓨터]  화면에서 입력(출처·검증·가설·캘린더…) → inbox 폴더에 '제출 파일' 저장
     │  GitHub Desktop으로 올리기(Push)
     ▼
[GitHub 저장소]  state/ 공개 원장 파일 + inbox/ 제출 파일
     │  평일 08:00~18:59(한국시간) 10분마다 + 제출 파일을 올릴 때마다
     ▼
[GitHub Actions]  원장 복원 → 제출 파일 검증·반영 → 브리핑·판정·모의운용 작업 → 원장 저장
     │
     ▼
[GitHub Pages]  https://내아이디.github.io/signal-ledger/   (누구나 볼 수 있는 읽기 전용 사이트)
```

---

## 0. 먼저 알아 둘 것 — 무엇이 공개되나요?

| 구분 | 공개 여부 | 설명 |
|---|---|---|
| 브리핑·심층검증·가설·판정·모의운용 원장·분기 전망·운영 상태 | **공개** | 저장소의 `state/` 폴더와 공개 사이트 |
| 내가 올린 제출 파일과 처리 결과 | **공개** | `inbox/`, `inbox/processed/` |
| 프로그램 코드 | **공개** | |
| **내 보유종목·거래 기록** | 비공개 | 내 컴퓨터 `data/` 폴더에만 있음. GitHub에 올라가지 않음(`.gitignore`로 막음) |
| **로그인 아이디·비밀번호** | 비공개 | 내 컴퓨터에만 있음 |
| **API 키** | 비공개 | GitHub **Secrets**에만 넣음. 파일에 적지 않음. 실행 기록(로그)에도 가려짐 |
| 공급자 원본 응답(KRX·DART·네이버 등) | 비공개 | 이용조건을 확인하지 못해 공개하지 않음. 원본의 해시값과 출처 링크만 공개 |
| 관찰하지 않는 종목의 KRX 가격 | 비공개 | 기록(가설·검증·모의운용)이 인용하는 종목과 지수 가격만 공개 원장에 남김 |

> 공개 사이트에는 "투자 권유가 아니며 실제 주문 기능이 없다"는 문구가 모든 화면에 붙습니다.
> 그래도 공개 저장소이므로 **누구나 내 연구 기록을 볼 수 있다**는 점은 감안하세요.

---

## 1. GitHub 계정 만들기 (5분)

1. https://github.com 접속 → **Sign up**
2. 이메일·비밀번호·아이디(영문) 입력 → 이메일로 온 인증 코드 입력
3. 무료 요금제(Free) 그대로 두면 됩니다.

아이디는 사이트 주소에 들어갑니다: `https://아이디.github.io/signal-ledger/`

## 2. GitHub Desktop 설치 (5분)

명령어 없이 마우스로 올리고 받을 수 있는 공식 프로그램입니다.

1. https://desktop.github.com 에서 내려받아 설치
2. 실행 → **Sign in to GitHub.com** → 브라우저에서 로그인 허용
3. 이름·이메일 설정 화면은 그대로 **Finish**

## 3. (이미 내 컴퓨터에서 써 왔다면) 지금까지의 기록을 공개 원장의 출발점으로 만들기

처음 설치했다면 건너뛰세요.

1. `run_web.bat` 창이 열려 있으면 닫습니다.
2. `first_publish.bat` 더블클릭 → `state` 폴더가 생깁니다.
   계정·보유종목·원본 응답은 들어가지 않습니다.

## 4. 내 컴퓨터를 '편집기 모드'로 바꾸기

`signal-ledger` 폴더의 `.env` 파일을 메모장으로 열고 다음 줄을 넣거나 고칩니다.

```
SL_MODE=editor
```

편집기 모드에서는 화면에서 저장 버튼을 눌러도 내 DB가 바로 바뀌지 않고,
먼저 규칙 검사를 한 뒤 `inbox` 폴더에 **제출 파일**이 생깁니다. 화면 위쪽에 노란 안내가 보이면 성공입니다.
(보유종목 입력은 예외로, 계속 내 컴퓨터에만 바로 저장됩니다.)

## 5. 저장소 만들고 올리기 (10분)

1. GitHub Desktop → 메뉴 **File → Add local repository…**
2. **Choose…** 로 `signal-ledger` 폴더 선택
3. "This directory does not appear to be a Git repository" 가 나오면 **create a repository** 클릭
   - Name: `signal-ledger`
   - 나머지는 그대로 → **Create repository**
4. 왼쪽 **Changes** 목록을 훑어보며 아래 파일이 **없는지** 확인합니다.
   - `.env`, `data/` 폴더 안의 파일, `*.db`, `holdings…json`
   - 있으면 멈추고 `.gitignore` 파일이 폴더에 있는지 확인하세요(압축 해제 때 빠지는 경우가 있음).
5. 아래쪽 Summary에 `처음 올리기` 입력 → **Commit to main**
6. 위쪽 **Publish repository** 클릭
   - ⚠️ **Keep this code private 체크를 해제**합니다(공개여야 Actions가 무료이고 Pages가 열립니다).
   - **Publish repository**

## 6. API 키를 GitHub Secrets에 넣기 (10분)

키는 **절대 파일에 적어서 올리지 마세요.** GitHub의 비밀 금고(Secrets)에만 넣습니다.

1. 브라우저에서 `https://github.com/내아이디/signal-ledger` 접속
2. **Settings** → 왼쪽 **Secrets and variables** → **Actions**
3. **Secrets** 탭 → **New repository secret** 을 눌러 하나씩 추가(이름은 정확히 대문자로):

| Name | Secret에 넣을 값 | 없으면 |
|---|---|---|
| `KRX_API_KEY` | KRX 정보데이터시스템 Open API 인증키 | 공식 가격·마감 브리핑이 '연결 필요' |
| `DART_API_KEY` | DART Open API 인증키 | 공시 매핑 '연결 필요' |
| `FRED_API_KEY` | FRED API 키 | 해외 지표 '연결 필요' |
| `GEMINI_API_KEY` | Gemini API 키 | AI 판단기 '연결 필요'(모의 주문 없음) |

   그리고 KRX 키를 넣을 때는 **반드시 함께**:

| Name | Secret에 넣을 값 | 이유 |
|---|---|---|
| `SL_STATE_KEY` | 내 컴퓨터에서 `python -m app.ci gen-key`로 만든 한 줄 | 종목·KRX 가격·시세 기록을 공개 저장소에 **암호문**으로만 저장 |

   KRX OPEN API 약관은 받은 자료를 제3자에게 제공하는 것을 금지합니다. 공개 저장소는 누구나 내려받을 수 있으므로
   이 자료들은 암호화해서 저장하고, 사이트에는 기록에 필요한 숫자만 "KRX 통계정보" 출처와 함께 보여 줍니다.
   `KRX_API_KEY`가 있는데 `SL_STATE_KEY`가 없으면 실행이 **일부러 멈춥니다**(평문으로 새어 나가지 않게).
   같은 `SL_STATE_KEY`를 내 컴퓨터 `.env`에도 넣어야 `refresh_local.bat`이 동작합니다.
   이 열쇠를 잃어버리면 암호화된 가격 기록을 다시 읽을 수 없으니, 비밀번호 관리 앱 등에 따로 보관하세요.

4. **Variables** 탭 → **New repository variable**:

| Name | Value |
|---|---|
| `GEMINI_MODEL` | 쓸 Gemini 모델 이름(직접 확인한 정확한 이름) |
| `NAVER_QUOTE_ENABLED` | 네이버 시세 이용조건을 직접 확인했다면 `true`, 아니면 만들지 않음 |

키를 넣지 않은 기능은 화면에 '연결 필요'로 표시될 뿐 오류로 멈추지 않습니다.
키가 유출된 것 같으면 해당 사이트에서 **키를 새로 발급**받고 Secret 값을 바꾸세요.

## 7. 공개 사이트(GitHub Pages) 켜기 (2분)

1. 저장소 **Settings** → 왼쪽 **Pages**
2. **Build and deployment → Source** 를 **GitHub Actions** 로 선택 (저장 버튼 없음, 선택하면 끝)

## 8. 첫 실행 (5분)

1. 저장소 위쪽 **Actions** 탭
   - "Workflows aren't being run on this repository" 같은 안내가 나오면 **I understand… enable** 버튼을 누릅니다.
2. 왼쪽 **ledger** → 오른쪽 **Run workflow** → 초록 **Run workflow**
3. 1~3분 뒤 초록 체크(✓)가 되면 성공. 빨간 X면 눌러서 어느 단계가 실패했는지 봅니다(아래 문제 해결).
4. 사이트 주소: `https://내아이디.github.io/signal-ledger/`
   (Settings → Pages 화면 위쪽에도 주소가 표시됩니다. 처음엔 몇 분 걸릴 수 있습니다.)

이후에는 **평일 한국시간 08:00~18:59에 10분마다** 자동으로 실행됩니다.

## 9. 처음 한 번 해야 할 입력 (내 컴퓨터 화면에서)

`run_web.bat` → http://localhost:8000 → 로그인 → **관리·운영**

1. **거래소 캘린더**: KRX 공식 휴장일 공지를 직접 열어 확인한 뒤, 연도·공지 URL·휴장일 목록을 등록합니다.
   등록 전에는 평일이라도 거래일로 보지 않아 모든 예약 작업이 멈춰 있습니다(의도된 동작).
2. **예약 시각**: 개장 전·마감 후·정산 시각(예: 08:20 / 15:50 / 16:10). GitHub 실행 시각(10분 간격)에 맞춰 여유 있게.
3. 저장하면 `inbox` 폴더에 제출 파일이 생깁니다 → 다음 장의 방법으로 올립니다.

## 10. 평소 사용 순서

```
① run_web.bat → 화면에서 입력 → [저장] → inbox에 제출 파일 생성(규칙 미리 검사 통과한 것만)
② GitHub Desktop → Changes에 inbox/…json 확인 → Commit to main → Push origin
③ 1~3분 뒤 GitHub가 반영(제출 파일을 올리면 바로 실행됨)
④ GitHub Desktop → Fetch origin → Pull origin
⑤ run_web 창을 닫고 refresh_local.bat 실행 → 내 화면이 공개 원장 최신 상태로 갱신
   (관리·운영 → 제출 파일 보기 에서 '반영/거부'와 이유 확인)
```

- **출처 번호를 아직 모를 때**: 출처 등록 때 '참조 이름'(예: `samsung-q3-ir`)을 붙이면,
  같은 묶음이나 다음 입력에서 출처 칸에 `ref:samsung-q3-ir` 로 적어 가리킬 수 있습니다.
- **제출 파일 하나는 전부 반영되거나 전부 거부됩니다.** 거부되면 아무것도 바뀌지 않으니 고쳐서 다시 제출하세요.
- 보유종목은 ①의 화면에서 입력하면 내 컴퓨터에만 저장됩니다. `refresh_local.bat`은 보유종목을 지우지 않습니다.
  내 `.env`에 `KRX_API_KEY`가 있으면 보유종목 평가용 공식 가격도 내 컴퓨터에만 받아 옵니다.

## 11. 꼭 알아 둘 한계 (사실대로)

- **실행 시각은 보장되지 않습니다.** GitHub의 예약 실행은 몇 분~수십 분 늦거나 가끔 건너뜁니다.
  늦은 실행은 같은 날 안에서만 따라잡고, 정규장 모의판단은 실행된 10분 구간에만 이뤄집니다.
- **60일 규칙**: 공개 저장소에서 60일 동안 활동이 없으면 GitHub가 예약 실행을 끕니다.
  GitHub에서 메일이 오면 Actions 탭에서 **Enable workflow**를 누르면 됩니다.
  자동 커밋이 이 '활동'으로 인정되는지는 확인하지 못했습니다. 가끔 Actions 탭에서 최근 실행을 확인하세요.
- **해외 서버에서의 접속**: GitHub 실행기는 해외(주로 미국) 서버입니다. KRX·네이버 등이 해외 접속을 막으면
  운영 상태에 '접근 거부'로 기록됩니다. 이 서비스는 차단을 우회하지 않습니다.
  작성 환경에서 이 사이트들에 접속할 수 없어 **실제 GitHub 서버에서의 응답은 확인하지 못했습니다.**
- **KRX 데이터 공개 범위**: 공개 원장에는 기록이 인용하는 종목·지수의 일별 수치만 남기고 원본 응답은 올리지 않지만,
  KRX·DART·네이버의 재배포 이용조건은 직접 확인하지 못했습니다. 각 사이트 약관을 한 번 읽어 보세요.
- **다른 사람의 Pull Request를 병합하지 마세요.** 공개 저장소라 누구나 변경을 '제안'할 수 있지만,
  내가 병합하지 않는 한 원장에는 반영되지 않습니다.

## 12. 문제 해결

| 증상 | 확인할 것 |
|---|---|
| Actions가 빨간 X, "패키지 설치" 단계 | 잠시 후 **Re-run jobs**. GitHub 일시 장애인 경우가 많음 |
| "원장 실행" 단계 실패 | 단계를 펼쳐 마지막 줄의 오류 확인. 상태가 저장되지 않으므로 기록은 안전하고, 제출 파일은 다음 실행에서 다시 처리됨 |
| "deploy" 단계 실패 | Settings → Pages → Source가 **GitHub Actions** 인지 확인 |
| "상태 저장" 단계에서 push 실패 | Settings → Actions → General → Workflow permissions 가 **Read and write permissions** 인지 확인 |
| 사이트가 404 | 첫 배포 후 몇 분 기다리기. 주소의 저장소 이름 철자 확인 |
| 제출 파일이 '거부' | 관리·운영 → 제출 파일 보기에서 이유 확인 후 고쳐서 다시 제출 |
| refresh_local.bat 오류 "파일을 사용 중" | run_web 창을 닫고 다시 실행 |
| 내 화면이 사이트와 다름 | GitHub Desktop에서 Pull 했는지, refresh_local.bat을 실행했는지 확인 |

## 13. 내 컴퓨터에서 공개 사이트 미리 보기

`preview_site.bat` → `_site` 폴더에 사이트를 만들고 브라우저로 엽니다(GitHub에 올라가지 않음).
